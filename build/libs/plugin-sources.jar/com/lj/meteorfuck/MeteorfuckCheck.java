package com.lj.meteorfuck;

import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import com.lj.meteorfuck.vpark_1_0_0.No_Criticals;
import com.lj.meteorfuck.vpark_1_0_0.No_ElytraFly;
import com.lj.meteorfuck.vpark_1_0_0.No_Fly;
import com.lj.meteorfuck.vpark_1_0_0.No_KillAura;
import com.lj.meteorfuck.vpark_1_0_0.No_XRay;

/**
 * 反外挂调度器：统一注册事件监听，并把事件分发给各检测模块。
 *
 * <p>{@code No_KillAura}、{@code No_Criticals} 都是纯函数文件，自身不注册任何监听；
 * 所有的事件注册与定时任务都集中在本类，便于统一启停。</p>
 */
public final class MeteorfuckCheck implements Listener {

	/** 检测模块 tick 间隔（单位：tick，20 tick = 1 秒）。 */
	private static final long TICK_INTERVAL = 20L;

	/** 可开关的功能名：杀戮光环检测。 */
	public static final String TOOL_KILL_AURA = "No_KillAura";
	/** 可开关的功能名：刀暴检测。 */
	public static final String TOOL_CRITICALS = "No_Criticals";
	/** 可开关的功能名：反飞行检测。 */
	public static final String TOOL_FLY = "No_Fly";
	/** 可开关的功能名：反鞘翅飞行（平飞 / 悬停）检测。 */
	public static final String TOOL_ELYTRA_FLY = "No_ElytraFly";
	/** 可开关的功能名：反透视检测。 */
	public static final String TOOL_XRAY = "No_XRay";
	/** 全部可开关的功能名，供指令补全与 tool.yml 同步使用。 */
	public static final List<String> TOOL_NAMES = List.of(TOOL_KILL_AURA, TOOL_CRITICALS, TOOL_FLY,
			TOOL_ELYTRA_FLY, TOOL_XRAY);

	/**
	 * 功能开关缓存：由指令写入、由 tool.yml 恢复。
	 * 使用静态字段是为了与 {@link #start(Plugin)} 的调用顺序解耦。
	 */
	private static volatile boolean killAuraEnabled = true;
	private static volatile boolean criticalsEnabled = true;
	private static volatile boolean flyEnabled = true;
	private static volatile boolean elytraFlyEnabled = true;
	private static volatile boolean xrayEnabled = true;

	private static MeteorfuckCheck instance;

	private BukkitTask tickTask;

	private MeteorfuckCheck() {
	}

	/**
	 * 注册事件监听并启动定时任务，在 {@code onEnable} 中调用一次即可（重复调用会被忽略）。
	 *
	 * @param plugin 插件主类
	 */
	public static void start(Plugin plugin) {
		if (instance != null) {
			return;
		}
		MeteorfuckCheck check = new MeteorfuckCheck();
		plugin.getServer().getPluginManager().registerEvents(check, plugin);
		check.tickTask = Bukkit.getScheduler().runTaskTimer(plugin, check::tick,
				TICK_INTERVAL, TICK_INTERVAL);
		instance = check;

		// 兼容 /reload 场景：把已经在线的玩家补进检测状态
		for (Player player : Bukkit.getOnlinePlayers()) {
			No_KillAura.get().onJoin(player);
			No_Criticals.get().onJoin(player);
			No_Fly.get().onJoin(player);
			No_ElytraFly.get().onJoin(player);
		}
	}

	/**
	 * 停止定时任务，在 {@code onDisable} 中调用。
	 */
	public static void stop() {
		if (instance == null) {
			return;
		}
		if (instance.tickTask != null) {
			instance.tickTask.cancel();
			instance.tickTask = null;
		}
		instance = null;
	}

	/* ==================== 功能开关 ==================== */

	/**
	 * 设置某个功能开关的状态，由 /meteorfuck tool 指令与 tool.yml 调用。
	 *
	 * @param tool    功能名，取值见 {@link #TOOL_NAMES}
	 * @param enabled 是否启用
	 * @return 功能名是否有效
	 */
	public static boolean applyToolState(String tool, boolean enabled) {
		if (TOOL_KILL_AURA.equalsIgnoreCase(tool)) {
			killAuraEnabled = enabled;
			return true;
		}
		if (TOOL_CRITICALS.equalsIgnoreCase(tool)) {
			criticalsEnabled = enabled;
			return true;
		}
		if (TOOL_FLY.equalsIgnoreCase(tool)) {
			flyEnabled = enabled;
			return true;
		}
		if (TOOL_ELYTRA_FLY.equalsIgnoreCase(tool)) {
			elytraFlyEnabled = enabled;
			return true;
		}
		if (TOOL_XRAY.equalsIgnoreCase(tool)) {
			xrayEnabled = enabled;
			return true;
		}
		return false;
	}

	/**
	 * 在 {@link #TOOL_NAMES} 中按名字查找功能名（忽略大小写）。
	 *
	 * @return 匹配到的标准功能名，找不到时返回 {@code null}
	 */
	public static String matchTool(String input) {
		if (input == null) {
			return null;
		}
		for (String tool : TOOL_NAMES) {
			if (tool.equalsIgnoreCase(input)) {
				return tool;
			}
		}
		return null;
	}

	/** 杀戮光环检测是否启用。 */
	public static boolean isKillAuraEnabled() {
		return killAuraEnabled;
	}

	/** 刀暴检测是否启用。 */
	public static boolean isCriticalsEnabled() {
		return criticalsEnabled;
	}

	/** 反飞行检测是否启用。 */
	public static boolean isFlyEnabled() {
		return flyEnabled;
	}

	/** 反鞘翅飞行检测是否启用。 */
	public static boolean isElytraFlyEnabled() {
		return elytraFlyEnabled;
	}

	/** 反透视检测是否启用。 */
	public static boolean isXrayEnabled() {
		return xrayEnabled;
	}

	/* ==================== 定时任务 ==================== */

	private void tick() {
		if (killAuraEnabled) {
			No_KillAura.get().tick();
		}
		if (criticalsEnabled) {
			No_Criticals.get().tick();
		}
		if (flyEnabled) {
			No_Fly.get().tick();
		}
		if (elytraFlyEnabled) {
			No_ElytraFly.get().tick();
		}
		if (xrayEnabled) {
			No_XRay.get().tick();
		}
	}

	/* ==================== 事件分发 ==================== */

	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onJoin(PlayerJoinEvent event) {
		Player player = event.getPlayer();
		if (killAuraEnabled) {
			No_KillAura.get().onJoin(player);
		}
		if (criticalsEnabled) {
			No_Criticals.get().onJoin(player);
		}
		if (flyEnabled) {
			No_Fly.get().onJoin(player);
		}
		if (elytraFlyEnabled) {
			No_ElytraFly.get().onJoin(player);
		}
		if (xrayEnabled) {
			No_XRay.get().onJoin(player);
		}
	}

	@EventHandler(priority = EventPriority.MONITOR)
	public void onQuit(PlayerQuitEvent event) {
		Player player = event.getPlayer();
		No_KillAura.get().onQuit(player);
		No_Criticals.get().onQuit(player);
		No_Fly.get().onQuit(player);
		No_ElytraFly.get().onQuit(player);
		No_XRay.get().onQuit(player);
	}

	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onRespawn(PlayerRespawnEvent event) {
		Player player = event.getPlayer();
		if (killAuraEnabled) {
			No_KillAura.get().onRespawn(player);
		}
		if (criticalsEnabled) {
			No_Criticals.get().onRespawn(player);
		}
		if (flyEnabled) {
			No_Fly.get().onRespawn(player);
		}
		if (elytraFlyEnabled) {
			No_ElytraFly.get().onRespawn(player);
		}
	}

	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onTeleport(PlayerTeleportEvent event) {
		Player player = event.getPlayer();
		if (killAuraEnabled) {
			No_KillAura.get().onTeleport(player);
		}
		if (criticalsEnabled) {
			No_Criticals.get().onTeleport(player);
		}
		if (flyEnabled) {
			No_Fly.get().onTeleport(player);
		}
		if (elytraFlyEnabled) {
			No_ElytraFly.get().onTeleport(player);
		}
	}

	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onChangedWorld(PlayerChangedWorldEvent event) {
		Player player = event.getPlayer();
		if (killAuraEnabled) {
			No_KillAura.get().onTeleport(player);
		}
		if (criticalsEnabled) {
			No_Criticals.get().onTeleport(player);
		}
		if (flyEnabled) {
			No_Fly.get().onTeleport(player);
		}
		if (elytraFlyEnabled) {
			No_ElytraFly.get().onTeleport(player);
		}
		if (xrayEnabled) {
			No_XRay.get().onChangedWorld(player);
		}
	}

	/**
	 * 移动 / 转头分发。
	 *
	 * <p>注意：{@link PlayerTeleportEvent} 是 {@link PlayerMoveEvent} 的子类，
	 * 因此传送时本方法也会被调用，此时 {@code from} 与 {@code to} 跨度极大；
	 * 两个检测模块都内部处理了这种跳变，无需在此特判。</p>
	 */
	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onMove(PlayerMoveEvent event) {
		Location from = event.getFrom();
		Location to = event.getTo();
		Player player = event.getPlayer();

		// 离地状态需要每次移动都采样
		if (criticalsEnabled) {
			No_Criticals.get().onMove(player, from, to, player.isOnGround());
		}

		// 视角采样只在真正转动时进行，纯位移事件直接跳过，省掉一次查表与浮点运算
		if (killAuraEnabled && (from.getYaw() != to.getYaw() || from.getPitch() != to.getPitch())) {
			No_KillAura.get().onMove(player, from, to);
		}

		// 反飞行依赖每次移动的垂直位移与离地标记
		if (flyEnabled) {
			No_Fly.get().onMove(player, from, to, player.isOnGround());
		}

		// 鞘翅飞行同样依赖每次移动的垂直 / 水平位移
		if (elytraFlyEnabled) {
			No_ElytraFly.get().onMove(player, from, to, player.isOnGround());
		}
	}

	/**
	 * 破坏方块分发（反透视统计用）。
	 *
	 * <p>用 MONITOR 优先级是为了在方块被真正移除前拿到它，
	 * 这样「是否有暴露面」的判断才准确。</p>
	 */
	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onBlockBreak(BlockBreakEvent event) {
		if (!xrayEnabled) {
			return;
		}
		Block block = event.getBlock();
		No_XRay.get().onBlockBreak(event.getPlayer(), block, block.getType());
	}

	/**
	 * 攻击分发。只处理玩家直接造成的近战伤害，投射物等交给其它模块。
	 */
	@EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
	public void onDamage(EntityDamageByEntityEvent event) {
		if (!(event.getDamager() instanceof Player attacker)) {
			return;
		}
		EntityDamageEvent.DamageCause cause = event.getCause();
		if (cause == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
			if (killAuraEnabled) {
				No_KillAura.get().onAttack(attacker, event.getEntity(), cause);
			}
			if (criticalsEnabled) {
				No_Criticals.get().onAttack(attacker, event.isCritical());
			}
		} else if (killAuraEnabled && cause == EntityDamageEvent.DamageCause.ENTITY_SWEEP_ATTACK) {
			// 横扫不产生暴击，只送给杀戮光环检测（其内部会自行忽略）
			No_KillAura.get().onAttack(attacker, event.getEntity(), cause);
		}
	}
}
